=============================================
ilivalidator - checks interlis transfer files
=============================================

Features
========
- checks INTERLIS 1+2 transfer files
- enable/disable checks
- custum error messages

License
=======
ilivalidator is licensed under the LGPL (Lesser GNU Public License).

Status
======
ilivalidator is in development state.

System Requirements
===================
For the current version of ilivalidator, you will need a JRE (Java Runtime Environment) installed on your system, version 1.6 or later.
The JRE (Java Runtime Environment) can be downloaded for free from the Website <http://www.java.com/>.

Installing ilivalidator
=======================
To install ilivalidator, choose a directory and extract the distribution file there. 

Running ilivalidator
====================
ilivalidator can be started with

java -jar ilivalidator.jar [options] file.xtf
